COUNTY 67 — FINAL 1.0.0 SOURCE PACKAGE

This package is the consolidated playable Android source build. It folds the planned gameplay stages into one offline game slice: world simulation, driving, combat, missions, economy, factions, police, progression, save/load, weather, day/night and mobile controls.

Open county_67/ in Android Studio and build an APK with a local Android SDK/Gradle installation.
